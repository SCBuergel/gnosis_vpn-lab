Relay-fault test, FAULT run. vpn-lab (lab 1, Frankfurt), 2026-11-23, all times UTC.

Client: unmodified gnosis_vpn-client main e6b33f36 (worker 1.1.1, sha256 11a49a2248d5...), built from
source. Config = client-config.toml: piz-palu-prod preset of the 1.1.0 package, lab exit pinned, 1 hop,
min_paths_anonymity_floor = 3, channels to 9 relays (3 lab relays + 6 public relays, channels.txt).
Exit: hoprd 5.0.4 with gnosis_vpn-server 0.7.1.
Load: ping 1.1.1.1 every 0.2 s through the tunnel + one 2 MB download every 30 s.
Timeline: worker restart, connect, first payment, 5 MB warm-up, 150 s baseline, 8 min "fault" window,
90 s afterwards (phases.txt).
Fault: from 13:20:45 to 13:29:00 lab relay1 (0xc8e2faf5b2d4afd01f5ca86666f04045199926cd, 164.92.188.29)
dropped every packet it sent to the exit (iptables OUTPUT DROP to 164.92.129.245 and 10.114.0.10).
It kept answering the client. Downloads slowed to 0.7-1.7 Mbit/s from +169 s until the fault was removed.

Files
  summary.txt        download speeds and ping loss per phase
  downloads.csv      every 2 MB download; seconds_after_mark counts from the start of the fault window
  client-worker.log  the client's worker log of the whole run, INFO and above (DEBUG lines removed)
  exit.log           the exit's hoprd and gnosisvpn-server journal for the same time, INFO and above
  relay1.log, relay2.log, relay3.log   hoprd journals of the three lab relays, INFO and above
  phases.txt         the test driver's own timeline
  drops.txt          unix time and packets dropped so far by the rule on relay1 (0 in the control)
  exit-acct.txt      unix time, source address, packets received by the exit from that address so far
                     (164.92.188.29 and 10.114.0.2 are relay1)
The logs carry two marker lines starting with ########## at the start and end of the fault window.
Nothing else was removed or edited.

Lines worth looking at in client-worker.log
  hopr_transport "dead relayer verdict: SURB generation advanced"
  hopr_transport "marking SURBs that cannot bring a reply home invalid"
  hopr_protocol_session::socket::loss_report "session frames dropped in the last window"
  edgli::state_dump component="paths" (once a minute; reason="surbs_not_returning" also appears in the control)
