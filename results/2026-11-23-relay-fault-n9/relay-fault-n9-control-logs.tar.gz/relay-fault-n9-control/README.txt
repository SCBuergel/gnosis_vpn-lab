Relay-fault test, CONTROL run. vpn-lab (lab 1, Frankfurt), 2026-11-23, all times UTC.

Client: unmodified gnosis_vpn-client main e6b33f36 (worker 1.1.1, sha256 11a49a2248d5...), built from
source. Config = client-config.toml: piz-palu-prod preset of the 1.1.0 package, lab exit pinned, 1 hop,
min_paths_anonymity_floor = 3, channels to 9 relays (3 lab relays + 6 public relays, channels.txt).
Exit: hoprd 5.0.4 with gnosis_vpn-server 0.7.1.
Load: ping 1.1.1.1 every 0.2 s through the tunnel + one 2 MB download every 30 s.
Timeline: worker restart, connect, first payment, 5 MB warm-up, 150 s baseline, 8 min "fault" window,
90 s afterwards (phases.txt).
Control: the same timeline with no fault. The marks at 13:35:49 and 13:43:51 are time marks only.
Downloads stayed at 9.6-18.4 Mbit/s throughout. Run directly after the fault run, same machines and channels.

Files
  summary.txt        download speeds and ping loss per phase
  downloads.csv      every 2 MB download; seconds_after_mark counts from the start of the fault window
  client-worker.log  the client's worker log of the whole run, INFO and above (DEBUG lines removed)
  exit.log           the exit's hoprd and gnosisvpn-server journal for the same time, INFO and above
  relay1.log, relay2.log, relay3.log   hoprd journals of the three lab relays, INFO and above
  phases.txt         the test driver's own timeline
  drops.txt          unix time and packets dropped so far by the rule on relay1 (0 in the control)
  exit-acct.txt      unix time, source address, packets received by the exit from that address so far
                     (164.92.188.29 and 10.114.0.2 are relay1)
The logs carry two marker lines starting with ########## at the start and end of the fault window.
Nothing else was removed or edited.

Lines worth looking at in client-worker.log
  hopr_transport "dead relayer verdict: SURB generation advanced"
  hopr_transport "marking SURBs that cannot bring a reply home invalid"
  hopr_protocol_session::socket::loss_report "session frames dropped in the last window"
  edgli::state_dump component="paths" (once a minute; reason="surbs_not_returning" also appears in the control)
